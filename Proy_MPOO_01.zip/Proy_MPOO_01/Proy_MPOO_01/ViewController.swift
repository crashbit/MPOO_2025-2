//
//  ViewController.swift
//  Proy_MPOO_01
//
//  Created by iOS Dev Lab on 17/02/25.
//

import UIKit

class ViewController: UIViewController {

    var nombre: String = "Luis"
    @IBOutlet weak var letrero: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        letrero.text = nombre
        
    }

    
}

