//
//  ViewController.swift
//  Proy_MPOO_02
//
//  Created by Germán Santos Jaimes on 19/02/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var letrero: UILabel!
    var number: Int = 0
    
    @IBOutlet weak var caja: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        letrero.text = "0"
    }

    @IBAction func sumar(_ sender: UIButton) {
        var contenido = caja.text!
        
        let otroNumero = Int(contenido)
        number = (otroNumero)!
        
        if number > 9{
            number = 10
            sender.tintColor = .red
        }else{
            number = number + 1
        }
        letrero.text = String(number)
    }
    
    

}

